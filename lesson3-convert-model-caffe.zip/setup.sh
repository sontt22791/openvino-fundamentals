source /opt/intel/openvino/bin/setupvars.sh -pyver 3.5

export PATH=/opt/intel/openvino/deployment_tools/model_optimizer:/opt/intel/openvino/deployment_tools/model_optimizer/venv/bin:/usr/local/sbin:/usr/local/bin:/usr/sbin:/usr/bin:/sbin:/bin

export PYTHONPATH=/opt/intel/openvino/python/python3.5:/opt/intel/openvino/python/python3:/opt/intel/openvino/deployment_tools/open_model_zoo/tools/accuracy_checker:/opt/intel/openvino/deployment_tools/model_optimizer:/opt/intel/openvino/deployment_tools/model_optimizer/venv/lib/python3.5/site-packages:/usr/lib/python35.zip:/usr/lib/python3.5:/usr/lib/python3.5/plat-x86_64-linux-gnu:/usr/lib/python3.5/lib-dynload:/usr/lib/python3.5/site-packages:/usr/local/lib/python3.5/dist-packages:/usr/lib/python3/dist-packages

alias python=python3
